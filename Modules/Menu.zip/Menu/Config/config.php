<?php

return [
    'name' => 'Menu',
];
